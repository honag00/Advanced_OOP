﻿using IRenameRule;
using System;
using System.Text;

namespace PrefixRule
{
    public class PrefixRule : IRenameRule.IRule
    {
        static List<string> UpperCase(List<string> file)
        {
            for (int i = 0; i < file.Count; i++)
            {
                char[] Temp = file[i].ToCharArray();
                for (int j = 0; j < Temp.Length; j++)
                {
                    if (j == 0 || Temp[j - 1] == ' ')
                    {
                        Temp[j] = Char.ToUpper(Temp[j]);
                    }
                }
                file[i] = new string(Temp);
            }

            return file;
        }

        public List<string> Rename(List<string> file, string Word)
        {
            UpperCase(file);

            for (int i = 0; i < file.Count; i++)
            {
                string[] tokens = Word.Split(new string[] { " " }, StringSplitOptions.None);
                string right = tokens[1];
                StringBuilder builder = new StringBuilder(right + " " + file[i]);
                file[i] = builder.ToString();
            }

            return file;
        }
    }
}