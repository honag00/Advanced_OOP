﻿using IRenameRule;
using System;
using System.Text;

namespace ReplaceRule
{
    public class ReplaceRule : IRenameRule.IRule
    {
        public List<string> Rename(List<string> file, string Word)
        {
            string Temp;
            string Facebook;
            string Google;

            for (int i = 0; i < file.Count; i++)
            {
                string[] tokens = file[i].Split(new string[] { "." }, StringSplitOptions.None);
                string LeftFile = tokens[0];
                string RightLife = tokens[1];

                string[] vs = Word.Split(new string[] { " => " }, StringSplitOptions.None);
                string repgg = vs[0];
                Facebook = vs[1];

                string[] vs1 = repgg.Split(new string[] { " " }, StringSplitOptions.None);
                Google = vs1[1];

                StringBuilder builder = new StringBuilder(LeftFile + " " + Google + "." + RightLife);
                file[i] = builder.ToString();
                Temp = file[i].Replace(Google, Facebook);
                file[i] = Temp;
            }

            return file;
        }
    }
}