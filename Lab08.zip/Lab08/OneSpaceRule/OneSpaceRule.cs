﻿using IRenameRule;
using System;
using System.Text;

namespace OneSpaceRule
{
    public class OneSpaceRule : IRenameRule.IRule
    {
        static List<string> Rename_1(List<string> file)
        {
            for (int i = 0; i < file.Count; i++)
            {
                StringBuilder temp = new StringBuilder(file[i]);
                temp.Replace("-", " ");
                temp.Replace("_", " ");
                string newfile = temp.ToString();
                file[i] = newfile;
            }
            return file;
        }

        public List<string> Rename(List<string> file, string Word)
        {
            Rename_1(file);
            for (int i = 0; i < file.Count; i++)
            {
                string Temp = file[i];
                for (int j = 0; j < Temp.Length; j++)
                {
                    if (Temp[j] == ' ' && Temp[j - 1] == ' ')
                    {
                        Temp = Temp.Remove(j, 1);
                        j--;
                    }
                }
                file[i] = Temp;
            }

            return file;
        }
    }
}