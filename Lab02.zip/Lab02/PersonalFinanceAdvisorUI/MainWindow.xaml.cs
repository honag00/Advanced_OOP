﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;
using System.Security.Policy;


namespace PersonalFinanceAdvisorUI
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            labelintruc.Content = "Enter your balance";
        }
        
        
        private void Calculate_click(object sender, RoutedEventArgs e)
        {

            double money = double.Parse(dataTextBox.Text);

            CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");
            string message = money.ToString("#,###", cul.NumberFormat);

            double necessities = money * 0.55;
            Necessities.Content = "Necessities: " + $"{necessities:c}";

            double longterm = money * 0.1;
            Longterm.Content = "Long term: " + $"{longterm:c}";

            double entertainment = money * 0.1;
            Entertainment.Content = "Entertainment: " + $"{entertainment:c}";

            double education = money * 0.1;
            Education.Content = "Education: " + $"{education:c}";

            double financial = money * 0.1;
            Financial.Content = "Financial: " + $"{financial:c}";

            double give = money * 0.05;
            Give.Content = "Give: " + $"{give:c}";
        }
    }
}
