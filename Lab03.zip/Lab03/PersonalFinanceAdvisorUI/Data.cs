﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalFinanceAdvisorUI
{
    class Data
    {
        public double necessities0 { get; set; }
        public double longterm0 { get; set; }
        public double entertainment0 { get; set; }
        public double education0 { get; set; }
        public double financial0 { get; set; }
        public double give0 { get; set; }
    }
}
