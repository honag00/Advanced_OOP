﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Globalization;
using System.Security.Policy;
using Microsoft.VisualBasic;


namespace PersonalFinanceAdvisorUI
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        Data? data = null;


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            labelintruc.Content = "Enter your balance";

        }

        private void Calculate_click(object sender, RoutedEventArgs e)
        {

            double money = double.Parse(dataTextBox.Text);

            CultureInfo cul = CultureInfo.GetCultureInfo("vi-VN");
            string message = money.ToString("#,###", cul.NumberFormat);
            
            var data = new Data
            {
                necessities0 = money * 0.55,
                longterm0 = money * 0.1,
                entertainment0 = money * 0.1,
                education0 = money * 0.1,
                financial0 = money * 0.1,
                give0 = money * 0.05
            };
            Necessities.Content = "Necessities: " + $"{data.necessities0:c}";
            Longterm.Content = "Longterm: " + $"{data.longterm0:c}";
            Entertainment.Content = "Entertainment: " + $"{data.entertainment0:c}";
            Education.Content = "Education: " + $"{data.education0:c}";
            Financial.Content = "Financial: " + $"{data.financial0:c}";
            Give.Content = "Give: " + $"{data.give0:c}";

            DataContext = data;
            
        }
        
    }
}
