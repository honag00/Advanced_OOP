﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace Lab09
{
    class RawToRename_Convert : IValueConverter
    {
        public List<IRenameRule> Rules { get; set; } = new List<IRenameRule>();
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string origin = (string)value;
            string newname = origin;
            foreach (var rule in Rules)
            {
                newname = rule.Rename(newname);
            }
            return newname;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
