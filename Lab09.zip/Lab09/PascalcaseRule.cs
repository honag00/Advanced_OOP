﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab09
{
    public class PascalcaseRule : IRenameRule
    {
        public string Rename(string origin)
        {

            char[] temp = origin.ToCharArray();
            for (int j = 0; j < temp.Length; j++)
            {
                if (j == 0 || temp[j - 1] == ' ')
                {
                    temp[j] = Char.ToUpper(temp[j]);
                }
            }
            origin = new string(temp);


            return origin;
        }
    }
}
