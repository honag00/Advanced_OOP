﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab09
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public ObservableCollection<object> Origins0 = new ObservableCollection<object>();
        public ObservableCollection<object> Previews0 = new ObservableCollection<object>();

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var screen = new OpenFileDialog();

            if (screen.ShowDialog() == true)
            {
                var info = new FileInfo(screen.FileName);

                var item = new
                {
                    FullPath = screen.FileName,
                    FileName = info.Name
                };
                Origins0.Add(item);
                Previews0.Add(item);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            FileListView.ItemsSource = Origins0;
            PreListView.ItemsSource = Previews0;

            var converter = FindResource("RenameConverter") as RawToRename_Convert;
            Rules0.Add(new PrefixRule()
            {
                Prefix = "MyCV"
            });

            Rules0.Add(new SpecialCharRemoveRule()
            {
                BlackList = new List<char>()
                {
                    '-', '_'
                }
            });

            Rules0.Add(new OneSpaceRule());
            Rules0.Add(new PascalcaseRule());
            Rules0.Add(new SuffixRule()
            {
                Suffix = "Facebook"
            });
            converter!.Rules = Rules0;
        }

        List<IRenameRule> Rules0 = new List<IRenameRule>();

        private void Rename_Click(object sender, RoutedEventArgs e)
        {
            foreach (dynamic item in Origins0)
            {
                string newName = item.FileName;

                foreach (var rule in Rules0)
                {
                    newName = rule.Rename(newName);
                }

                var info = new FileInfo(item.FullPath);
                var folder = info.Directory;
                var newPath = $"{folder}\\{newName}";
                File.Move(item.FullPath, newPath);
            }

            MessageBox.Show($"Renamed {Origins0.Count} files!");
        }
    }
}
