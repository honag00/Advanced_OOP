﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Lab10
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public ObservableCollection<object> Origins0 = new ObservableCollection<object>();
        public ObservableCollection<object> Previews0 = new ObservableCollection<object>();

        public List<string> Savefile = new List<string>();

        private void Add_click(object sender, RoutedEventArgs e)
        {
            var screen = new OpenFileDialog();

            if (screen.ShowDialog() == true)
            {
                var info = new FileInfo(screen.FileName);

                var item = new
                {
                    FullPath = screen.FileName,
                    FileName = info.Name
                };
                Origins0.Add(item);
                Previews0.Add(item);
                Savefile.Add(item.FullPath);
            }
            saveWork("Lab10-progress.txt");
        }


        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            loadWork("Lab10-progress.txt");

            FileListView.ItemsSource = Origins0;
            PreListView.ItemsSource = Previews0;

            var converter = FindResource("RenameConverter") as RawToRenameConvert;
            Rules0.Add(new PrefixRule()
            {
                Prefix = "CV"
            });

            Rules0.Add(new SpecCharRemoveRule()
            {
                BlackList = new List<char>()
                {
                    '-', '_'
                }
            });

            Rules0.Add(new OneSpaceRule());

            Rules0.Add(new PascalcaseRule());

            Rules0.Add(new SuffixRule()
            {
                Suffix = "Facebook"
            });
            converter!.Rules = Rules0;
        }

        List<IRenameRule> Rules0 = new List<IRenameRule>();

        private void Rename_Click(object sender, RoutedEventArgs e)
        {
            foreach (dynamic item in Origins0)
            {
                string NewName0 = item.FileName;

                foreach (var rule in Rules0)
                {
                    NewName0 = rule.Rename(NewName0);
                }

                var info = new FileInfo(item.FullPath);
                var folder = info.Directory;
                var NewPath = $"{folder}\\{NewName0}";
                File.Move(item.FullPath, NewPath);
            }

            MessageBox.Show($"Renamed {Origins0.Count} files!");
            Savefile.Clear();
            saveWork("Lab10-progress.txt");
        }

        public ObservableCollection<object> SaveOrigins0 = new ObservableCollection<object>();

        private void loadWork(string workFile)
        {
            var lines = File.ReadAllLines(workFile).ToList();

            for (int i = 2; i < lines.Count; i++)
            {
                var info = new FileInfo(lines[i]);

                dynamic item = new
                {
                    FullPath = lines[i],
                    FileName = info.Name,
                };

                SaveOrigins0.Add(item);
                Previews0.Add(item);
                Savefile.Add(lines[i]);
            }

            foreach (var i in SaveOrigins0)
            {
                Origins0.Add(i);
            }
        }

        private void saveWork(string workFile)
        {
            File.Delete(workFile);
            string exeFolder = AppDomain.CurrentDomain.BaseDirectory;
            string Folder = $"{exeFolder}";


            using (StreamWriter sw = File.AppendText(workFile))
            {
                sw.WriteLine($"File: {Origins0.Count}");

                foreach (var f in Origins0)
                {
                    sw.WriteLine(f);
                }
            }
        }
    }
}
