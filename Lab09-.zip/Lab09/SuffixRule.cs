﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab09
{
    public class SuffixRule : IRenameRule
    {
        public string Suffix { get; set; } = "";
        public string Rename(string origin)
        {
            string[] tokens = origin.Split(new string[] { "." }, StringSplitOptions.None);
            string left = tokens[0];
            string right = tokens[1];
            StringBuilder builder = new StringBuilder(left + " " + Suffix + "." + right);
            string result = builder.ToString();
            return result;
        }
    }
}
