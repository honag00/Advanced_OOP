﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Theory_3
{
    class Data
    {
        public string PhoneName0 { get; set; }
        public string Factory0 { get; set; }
        public string Price0 { get; set; }
        public string Image0 { get; set; }
    }
}
