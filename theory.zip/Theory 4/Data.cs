﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;
using System.Windows.Data;

namespace Theory_4
{
    public class Data
    {
        public string PhoneName0 { get; set; }
        public string Factory0 { get; set; }
        public string Price0 { get; set; }
        public string Image0 { get; set; }
    }
}
